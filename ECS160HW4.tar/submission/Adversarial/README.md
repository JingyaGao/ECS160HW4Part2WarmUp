
We tested the maxTweeter.c file with the input csv files that we submitted, but we did not find any crash. 
