less_columns.csv 	line 72		calling strdup with null pointer because getField(line, 9) returns null	
